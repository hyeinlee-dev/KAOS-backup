extern void addShmFITS (FImage *fip, TelStatShm *telstatshmp);

/* For RCS Only -- Do Not Edit
 * @(#) $RCSfile: telfits.h,v $ $Date: 2001/04/19 21:12:14 $ $Revision: 1.1.1.1 $ $Name:  $
 */
