extern void rotx (double p[3], double a);
extern void roty (double p[3], double a);
extern void rotz (double p[3], double a);

/* For RCS Only -- Do Not Edit
 * @(#) $RCSfile: rot.h,v $ $Date: 2001/04/19 21:12:14 $ $Revision: 1.1.1.1 $ $Name:  $
 */
