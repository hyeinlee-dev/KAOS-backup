/***************************************************************************
 * findobj.h  - Header file for findobj.c
 *                            -------------------
 *   begin                : Thu May 30 2001
 *   copyright            : (C) 2001 by jca
 *   email                : jcarmstrong@torusoptics.com
 *
 *  30 May 2001 - jca started hack of findstars to generate pixel masks
 ***************************************************************************/
