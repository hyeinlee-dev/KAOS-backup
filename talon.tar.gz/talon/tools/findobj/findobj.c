/***************************************************************************
 * findobj.c  - detects and reports on items found in images
 *
 *                            -------------------
 *
 * $Id: findobj.c,v 1.10 2005/01/06 23:17:32 steve Exp $
 * $Log: findobj.c,v $
 * Revision 1.10  2005/01/06 23:17:32  steve
 * Fixed bug that still required WCS even for pixel-only position report
 *
 * Revision 1.9  2003/03/13 00:29:35  steve
 * Revised link to setWCSFITS so that it did not require library inclusion for apps that didn't use smear features
 *
 * Revision 1.8  2003/03/10 05:22:50  steve
 * Phase II streak detection -- untracked image (smear) support
 *
 * Revision 1.7  2002/12/28 20:09:36  steve
 * made ip.cfg location settable by caller
 *
 * Revision 1.6  2002/11/25 19:53:37  steve
 * updated for new streak detection library code
 *
 *
 ***************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>

#include "P_.h"
#include "astro.h"
#include "circum.h"
#include "fits.h"
#include "fieldstar.h"
#include "telenv.h"
#include "strops.h"
#include "wcs.h"

static void usage (char *p);
static void findem (char *fn);

static char *progname;
static int fflag;
static int gflag;
static int rflag;
static int hflag;
static int sflag;
static int lflag;
static int aflag;
static int pflag;
static int dflag;
static int xflag;
static int wflag;

int
main (int ac, char *av[])
{
    char *str;
    char oldIpCfg[256];

    // Save existing IP.CFG.... be sure to restore before any exit!!
    strcpy(oldIpCfg,getCurrentIpCfgPath());

    /* crack arguments */
    progname = basenm(av[0]);
    for (av++; --ac > 0 && *(str = *av) == '-'; av++)
    {
        char c;
        while ((c = *++str))
        {
            switch (c)
            {
                case 'r':
                    rflag++;
                    break;
                case 'h':
                    hflag++;
                    break;
                case 's':
                    sflag++;
                    break;
                case 'l':
                    lflag++;
                    break;
                case 'f':
                    fflag++;
                    break;
                case 'g':
                    gflag++;
                    break;
                case 'a':
                    lflag++;
                    aflag++;
                    break;
                case 'p':
                    pflag++;
                    break;
                case 'd':
                    dflag++;
                    break;
                case 'x':
                    xflag++;
                    break;
                case 'i':   /* alternate ip.cfg */
                    if (ac < 2)
                    {
                        fprintf(stderr, "-i requires ip.cfg pathname\n");
                        setIpCfgPath(oldIpCfg);
                        usage(progname);
                    }
                    setIpCfgPath(*++av);
                    ac--;
                    break;
                case 'w': // write fits -- only for f/g
                    wflag++;
                    break;
                default:
                    setIpCfgPath(oldIpCfg);
                    usage (progname);
                    break;
            }
        }
    }

    if (ac == 0)
    {
        setIpCfgPath(oldIpCfg);
        usage (progname);
    }

    // Insure we load the settings
    loadIpCfg();

    // defaults to -sx (standard findstars)
    if (!(pflag|dflag|rflag|hflag|xflag)) xflag++;
    if (!(sflag|lflag|fflag|gflag)) sflag++;

    if (wflag && !(fflag|gflag))
    {
        fprintf(stderr,"-w option can only be used with -f or -g\n");
    }
    else
    {
        // DO IT! For all files!
        while (ac-- > 0)
        {
            findem (*av++);
        }
    }
    setIpCfgPath(oldIpCfg);
    return (0);
}

static void
usage (char *p)
{
    fprintf (stderr, "Usage: %s [options] *.fts\n", p);
    fprintf (stderr, "Purpose: list objects in FITS files\n");
    fprintf (stderr, "Type Options (choose output format with flags below):\n");
    fprintf (stderr, " -s: find stars (default).  [Use 'findstars' program for more advanced version.]\n");
    fprintf (stderr, " -f: find stars in a fixed exposure image (smears)\n");
    fprintf (stderr, " -g: find anomolous items (geosync satellites) in fixed exposure\n");
    fprintf (stderr, "     (may combine with -f, i.e. -fg == find both)\n");
    fprintf (stderr, " -l: find linear features (streaks) in standard tracked exposure\n");
    fprintf (stderr, "Format flags:\n");
    fprintf (stderr, " -a:  (-l only) report on all objects (stars and streak) found with streak detection\n");
    fprintf (stderr, " -p: report in pixel coordinates (does not require WCS solution to be successful)\n");
    fprintf (stderr, " -r: report WCS data in rads\n");
    fprintf (stderr, " -d: report WCS data in degrees\n");
    fprintf (stderr, " -x: report WCS data HH:MM:SS, DD:MM:SS format\n");
    fprintf (stderr, " -h: high prec format: Az Alt RA Dec M HW VW JD expt (may combine w/prdx)\n");
    fprintf (stderr, "Other Options:\n");
    fprintf (stderr, " -i path: specify alternate ip.cfg location\n");
    fprintf (stderr, " -w:  (-f, -g only) save file back with WCS solution\n");

    exit (1);
}

static int noabort()
{
    return 0;
}

static void
findem (char *fn)
{
    FImage fimage, *fip = &fimage;
    Now now, *np = &now;
    double eq = 0;
    double lst = 0;
    double expt = 0;
    StreakData *streakList;
    char buf[1024];
    StarStats *ssp;
    int i,ns=0,nl=0,fd;

    // print header with filename //
    printf("# %s\n", fn);
    /* open and read the image */
    fd = open (fn, O_RDONLY);
    if (fd < 0)
    {
        fprintf (stderr, "%s: %s\n", fn, strerror(errno));
        return;
    }
    initFImage (fip);
    i = readFITS (fd, fip, buf);
    (void) close (fd);
    if (i < 0)
    {
        fprintf (stderr, "%s: %s\n", fn, buf);
        resetFImage (fip);
        return;
    }

    /* gather local info if want alt-az */
    if (hflag)
    {
        double tmp;
        memset (np, 0, sizeof(Now));

        if (getRealFITS (fip, "JD", &tmp) < 0)
        {
            fprintf (stderr, "%s: no JD\n", fn);
            resetFImage (fip);
            return;
        }
        mjd = tmp - MJD0;
        if (getStringFITS (fip, "LATITUDE", buf) < 0)
        {
            fprintf (stderr, "%s: no LATITUDE\n", fn);
            return;
        }
        if (scansex (buf, &tmp) < 0)
        {
            fprintf (stderr, "%s: badly formed LATITUDE: %s\n", fn, buf);
            return;
        }
        lat = degrad(tmp);
        if (getStringFITS (fip, "LONGITUD", buf) < 0)
        {
            fprintf (stderr, "%s: no LONGITUD\n", fn);
            return;
        }
        if (scansex (buf, &tmp) < 0)
        {
            fprintf (stderr, "%s: badly formed LONGITUD: %s\n", fn, buf);
            return;
        }
        lng = degrad(tmp);
        temp = getStringFITS (fip, "WXTEMP", buf) ? 10 : atof(buf);
        pressure = getStringFITS (fip, "WXPRES", buf) ? 1010 : atof(buf);

        elev = 0;   /* ?? */

        if (getRealFITS (fip, "EQUINOX", &eq) < 0
                && getRealFITS (fip, "EPOCH", &eq) < 0)
        {
            fprintf (stderr, "%s: no EQUINOX or EPOCH\n", fn);
            resetFImage (fip);
            return;
        }
        year_mjd (eq, &eq);
        if (getStringFITS (fip, "LST", buf) < 0)
        {
            fprintf (stderr, "%s: no LST\n", fn);
            return;
        }
        if (scansex (buf, &tmp) < 0)
        {
            fprintf (stderr, "%s: badly formed LST: %s\n", fn, buf);
            return;
        }
        lst = hrrad(tmp);
        if (getRealFITS (fip, "EXPTIME", &expt) < 0)
        {
            fprintf (stderr, "%s: no EXPTIME\n", fn);
            resetFImage (fip);
            return;
        }
    }

    // search for linear features //
    if (lflag)
    {
        double ra1, dec1;
        double ra2, dec2;
        char rastr1[32], decstr1[32];
        char rastr2[32], decstr2[32];
        int st,maybe;
        static int saiderr;

        saiderr = 0;
        (void) findStarsAndStreaks(fip->image,fip->sw,fip->sh,NULL,NULL,NULL,&streakList,&nl);
        st = maybe = 0;
        for (i=0; i<nl; i++)
        {
            if ((streakList[i].flags & STREAK_MASK))
            {
                st++;
                if ((streakList[i].flags & STREAK_MASK) == STREAK_MAYBE)
                {
                    maybe++;
                }
            }
        }
        if (aflag)
        {
            printf("# %d object%s detected\n", nl, nl==1 ? "" : "s");
        }
        printf("# %d object%s found to be streak-like\n",st, st==1 ? "" : "s");
        if (maybe)
        {
            printf("# %d considered likely to be%s true streak%s\n",st-maybe, st-maybe==1?" a":"", st-maybe==1?"":"s");
            printf("# %d considered as%s possible streak%s\n",maybe, maybe==1?" a":"", maybe==1?"":"s");
        }
        for (i=0; i<nl; i++)
        {
            if (aflag || (streakList[i].flags&STREAK_MASK) )
            {
                if (xy2RADec (fip, streakList[i].startX,streakList[i].startY, &ra1, &dec1) < 0)
                {
                    if (!saiderr++) fprintf (stderr, "%s: no WCS\n", fn);
                }
                else
                {
                    xy2RADec (fip, streakList[i].endX,streakList[i].endY, &ra2, &dec2);
                }
                if (pflag)
                {
                    printf("%4d,%4d (to %4d,%4d) slope: %2.4lf length: %3d walkStart: %4d,%4d walkEnd: %4d,%4d fwhmRatio: %2.4lf flags: %04X",
                           streakList[i].startX,streakList[i].startY, streakList[i].endX,streakList[i].endY,
                           streakList[i].slope,streakList[i].length,
                           streakList[i].walkStartX,streakList[i].walkStartY,
                           streakList[i].walkEndX,streakList[i].walkEndY,
                           streakList[i].fwhmRatio, streakList[i].flags);
                }
                if (!saiderr)
                {
                    if (rflag)
                    {
                        printf("% 9.6lf %9.6lf  % 9.6lf %9.6lf ", ra1,dec1,ra2,dec2);
                    }
                    else if (dflag)
                    {
                        printf("% 9.6lf %9.6lf  % 9.6lf %9.6lf ", raddeg(ra1),raddeg(dec1), raddeg(ra2),raddeg(dec2));
                    }
                    else if (xflag)
                    {
                        fs_sexa (rastr1, radhr (ra1), 2, 360000);
                        fs_sexa (decstr1, raddeg (dec1), 3, 36000);
                        fs_sexa (rastr2, radhr (ra2), 2, 360000);
                        fs_sexa (decstr2, raddeg (dec2), 3, 36000);
                        printf ("%s %s %s %s ", rastr1, decstr1, rastr2, decstr2);
                    }
                    else if (hflag)
                    {
                        printf("hi-prec format not supported for -l option");
                    }
                }
                printf("\n");
            } // end aflag || streak
        } // end for
    } // end lflag

    // start the standard findstars algorithm //
    if (sflag)
    {
        ns = findStatStars (fip->image, fip->sw, fip->sh, &ssp);
        printf("# %d Stars Found\n", ns);
        if (hflag) printf("# Format: Alt Az RA Dec Mag H-fwhm V-fwhm JD expt");
        else printf("# Format: %s %s Bright",pflag ? "X" : "RA", pflag ? "Y" : "Dec");
        printf(" (Coordinates are in %s)\n",
               pflag ? "Pixels" : rflag ? "Radians" : xflag ? "Sexagesimal" : "Degrees");

        for (i = 0; i < ns; i++)
        {
            StarStats *sp = &ssp[i];
            int x = sp->x;
            int y = sp->y;
            int bright = sp->p;
            double ra,dec;
            char coordStr[64];

            if (xy2RADec (fip, sp->x, sp->y, &ra, &dec) < 0 && !pflag)
            {
                fprintf (stderr, "%s: no WCS\n", fn);
                break;
            }
            if (pflag)
            {
                sprintf(coordStr, "%4d %4d",(int) (x+.5),(int) (y+.5));
            }
            else if (rflag)
            {
                sprintf(coordStr, "%9.6f %9.6f", ra, dec);
            }
            else if (dflag)
            {
                sprintf(coordStr, "%9.6f %9.6f", raddeg(ra), raddeg(dec));
            }
            else   // xflag, default
            {
                char rastr[32], decstr[32];
                fs_sexa (rastr, radhr (ra), 2, 360000);
                fs_sexa (decstr, raddeg (dec), 3, 36000);
                sprintf (coordStr, "%s %s", rastr, decstr);
            }
            if (hflag)
            {
                double mag, dmag;
                double apra, apdec;
                double alt, az;
                double ha;
                char altAzStr[64];

                apra = ra;
                apdec = dec;
                as_ap (np, eq, &apra, &apdec);
                ha = lst - apra;
                hadec_aa (lat, ha, apdec, &alt, &az);
                refract (pressure, temp, alt, &alt);

                starMag (&ssp[0], sp, &mag, &dmag);

                if (rflag)
                {
                    sprintf(altAzStr, "%9.6f %9.6f", az, alt);
                }
                else if (xflag)
                {
                    char azstr[32], altstr[32];
                    fs_sexa (azstr, raddeg (az), 3, 36000);
                    fs_sexa (altstr, raddeg (alt), 3, 36000);
                    sprintf (altAzStr, "%s %s", azstr, altstr);
                }
                else   // dflag, default
                {
                    sprintf(altAzStr, "%9.6f %9.6f", raddeg(az), raddeg(alt));
                }
                printf ("%s  %s %5.2f %5.2f %5.2f %14.6f %6.1f\n",
                        altAzStr, coordStr, mag, sp->xfwhm, sp->yfwhm, mjd+MJD0-expt/SPD, expt);
            }
            else
            {
                // print w/o h-prec options
                printf("%s %5d\n",coordStr, bright);
            }
        }

        if (ns >= 0)
        {
            free ((void *)ssp);
        }
        printf("\n");
        resetFImage (fip);
    }

    // Solve for smears
    if (fflag|gflag)
    {
        SmearData *smearList=NULL;
        int numSmears;
        int use_usno = 0;
        double huntrad =  degrad(0.20); // TODO: get this from ip.cfg?  What about camera, conflict?
        char str[256];
        char *chpath_default = "archive/catalogs/gsc";
        char *cdpath=NULL;
        char *chpath = chpath_default;
        char telchpath[1024];
        int rt;
        int useMidpoint = 1;

        telfixpath (telchpath, chpath);
        if (GSCSetup (cdpath, telchpath, str) < 0)
        {
            fprintf (stderr, "GSC: %s\n", str);
            resetFImage(fip);
            return;
        }

        SetWCSFunction(setWCSFITS); // must call this before calling findSmears

        rt = findSmears(fip, &smearList, &numSmears, gflag, use_usno, huntrad, noabort, str);
        if (rt < 0)
        {
            fprintf(stderr,"Error occurred in detecting smears\n");
            resetFImage(fip);
            return;
        }
        if (fflag)
        {
            printf("# %d qualified smears detected\n",numSmears);
        }
        if (gflag)
        {
            int i, count= 0;
            // count anomolies
            for (i=0; i<numSmears; i++)
            {
                if (!smearList[i].length) count++;
            }
            printf("# %d geosynchronous objects (or anomolies) found\n",count);
        }
        if (rt > 0)
        {
            printf("# WCS error: %s\n",str);
        }

        if (useMidpoint)
        {
            mjd += (expt/2)/SPD;
        }

        printf("# Coordinates refer to %s of %.1f second exposure at %14.6f\n",
               useMidpoint ? "midpoint" : "start", expt, mjd+MJD0-expt/SPD);
        if (hflag) printf("# Format: Alt Az RA Dec Mag H-fwhm V-fwhm JD expt");
        else printf("# Format: %s %s Bright Length",pflag ? "X" : "RA", pflag ? "Y" : "Dec");
        printf(" (Coordinates are in %s)\n",
               pflag ? "Pixels" : rflag ? "Radians" : xflag ? "Sexagesimal" : "Degrees");

        for (i = 0; i < numSmears; i++)
        {
            SmearData *pStr = &smearList[i];
            int x = pStr->startx;
            int y = pStr->starty;
            int length = pStr->length;
            int bright = pStr->bright;
            double ra,dec;
            char coordStr[64];

            if (!length)
            {
                if (!gflag) continue;   // anomolies -- do we want them? If not, skip
            }
            else
            {
                if (!fflag) continue;   // stars -- do we want them? If not, skip
            }

            if (rt == 0)
            {
                if (xy2RADec (fip, x, y, &ra, &dec) < 0)
                {
                    fprintf (stderr, "%s: no WCS\n", fn);
                    break;
                }
            }
            else
            {
                if (!pflag) break;
            }
            if (pflag)
            {
                sprintf(coordStr, "%4d %4d",(int) (x+.5),(int) (y+.5));
            }
            else if (rflag)
            {
                sprintf(coordStr, "%9.6f %9.6f", ra, dec);
            }
            else if (dflag)
            {
                sprintf(coordStr, "%9.6f %9.6f", raddeg(ra), raddeg(dec));
            }
            else   // xflag, default
            {
                char rastr[32], decstr[32];
                fs_sexa (rastr, radhr (ra), 2, 360000);
                fs_sexa (decstr, raddeg (dec), 3, 36000);
                sprintf (coordStr, "%s %s", rastr, decstr);
            }
            if (hflag)
            {
                double apra, apdec;
                double alt, az;
                double ha;
                char altAzStr[64];
                char xfwhmStr[40] = "N/A";
                char yfwhmStr[40] = "N/A";

                apra = ra;
                apdec = dec;
                as_ap (np, eq, &apra, &apdec);
                ha = lst - apra;
                hadec_aa (lat, ha, apdec, &alt, &az);
                refract (pressure, temp, alt, &alt);

                if (rflag)
                {
                    sprintf(altAzStr, "%9.6f %9.6f", az, alt);
                }
                else if (xflag)
                {
                    char azstr[32], altstr[32];
                    fs_sexa (azstr, raddeg (az), 3, 36000);
                    fs_sexa (altstr, raddeg (alt), 3, 36000);
                    sprintf (altAzStr, "%s %s", azstr, altstr);
                }
                else   // dflag, default
                {
                    sprintf(altAzStr, "%9.6f %9.6f", raddeg(az), raddeg(alt));
                }

                if (gflag)
                {
                    // we can report the fwhm on an anomoly
                    StarDfn sd;
                    StarStats ss;
                    char buf[256];
                    sd.rsrch = 10;
                    sd.rAp = 0;
                    sd.how = SSHOW_HERE;
                    if (0 != starStats((CamPixel *) fip->image, fip->sw, fip->sh, &sd, x, y, &ss, buf))
                    {
                        printf("# -- error w/starstats: %s\n",buf);
                        strcpy(xfwhmStr,"N/A");
                        strcpy(yfwhmStr,"N/A");
                    }
                    else
                    {
                        sprintf(xfwhmStr,"%5.2f",ss.xfwhm);
                        sprintf(yfwhmStr,"%5.2f",ss.yfwhm);
                    }
                }
                printf ("%s  %s  N/A  %s %s  %14.6f %6.1f\n", altAzStr, coordStr, xfwhmStr, yfwhmStr, mjd+MJD0-expt/SPD, expt);
            }
            else
            {
                // print w/o h-prec options
                printf("%s %5d %5d\n",coordStr, bright, length);
            }
        }

        // destroy list
        if (smearList)
        {
            free(smearList);
            smearList = NULL;
        }

        // if we want to write out the solved, FITS, do that now
        if (wflag && !rt)  // only if there IS a solution...
        {
            fd = open (fn, O_RDWR);
            if (fd < 0)
            {
                fprintf (stderr, "%s: %s\n", fn, strerror(errno));
                return;
            }
            if (0 > writeFITS (fd, fip, str, 0))
            {
                fprintf (stderr, "%s: Erroring writing: %s\n",fn, str);
            }
            (void) close (fd);
        }
        printf("\n");
        resetFImage (fip);
    }

}
