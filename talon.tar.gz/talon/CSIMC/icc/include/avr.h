// YOU SHOULD USE IO????.H!!!
#ifdef ATMEGA
#include "avr603.h"
#else
#include "avrclassic.h"
#endif
