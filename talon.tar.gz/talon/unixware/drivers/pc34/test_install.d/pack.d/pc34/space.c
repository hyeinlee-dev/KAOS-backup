/* space.c file for the Oregon Micro Systems, Inc, PC34 intelligent motor cntlr.
 */

/* For RCS Only -- Do Not Edit */
static char *rcsid[2] = {(char *)rcsid, "@(#) $RCSfile: space.c,v $ $Date: 2001/04/19 21:12:23 $ $Revision: 1.1.1.1 $ $Name:  $"};
