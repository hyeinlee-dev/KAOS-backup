/*
 *  @OSF_COPYRIGHT@
 *  COPYRIGHT NOTICE
 *  Copyright (c) 1990, 1991, 1992, 1993 Open Software Foundation, Inc.
 *  ALL RIGHTS RESERVED (MOTIF). See the file named COPYRIGHT.MOTIF for
 *  the full copyright text.
*/
/*
 * HISTORY
*/
/* $XConsortium: MenuUtilP.h /main/9 1995/07/13 17:37:16 drk $ */
/* (c) Copyright 1989, DIGITAL EQUIPMENT CORPORATION, MAYNARD, MASS. */
#ifndef _XmMenuUtilP_h
#define _XmMenuUtilP_h

#include <Xm/XmP.h>
#include <Xm/RowColumnP.h>

#ifdef __cplusplus
extern "C"
{
#endif

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration which encloses file. */
#endif

#endif  /* _XmMenuUtilP_h */
/* DON'T ADD STUFF AFTER THIS #endif */
