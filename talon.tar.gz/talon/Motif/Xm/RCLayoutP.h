/* $XConsortium: RCLayoutP.h /main/4 1995/07/15 20:54:35 drk $ */
/*
 *  @OSF_COPYRIGHT@
 *  COPYRIGHT NOTICE
 *  Copyright (c) 1990, 1991, 1992, 1993 Open Software Foundation, Inc.
 *  ALL RIGHTS RESERVED (MOTIF). See the file named COPYRIGHT.MOTIF for
 *  the full copyright text.
 */
/*
 * HISTORY
 */
#ifndef _XmRCLayoutP_h
#define _XmRCLayoutP_h

#include <Xm/RowColumnP.h>

#ifdef __cplusplus
extern "C"
{
#endif


#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration which encloses file. */
#endif

#endif  /* _XmRCLayoutP_h */
/* DON'T ADD STUFF AFTER THIS #endif */
